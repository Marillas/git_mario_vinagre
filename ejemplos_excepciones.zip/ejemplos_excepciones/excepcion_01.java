package ejemplos_excepciones;

public class excepcion_01 {

	//Divisi�n por cero y comprobaci�n del orden de excepciones
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int s=4/0;
		/*
		try {
			int s=4/0;
			System.out.println("el programa sigue");
			}
			catch (ArithmeticException e)
			{
			System.out.println("Division por 0");
			}
			catch (Exception e)
			{
			System.out.println("Excepcion general");
			}
			System.out.println("final del main");

	*/}

}
