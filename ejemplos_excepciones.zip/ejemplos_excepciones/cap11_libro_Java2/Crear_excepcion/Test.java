package ejemplos_excepciones.cap11_libro_Java2.Crear_excepcion;

public class Test
{
  public static void main(String[] args)
  {
    int x = 0;
    CMiClase obj = new CMiClase();
    try
    {
      obj.m(x);
    }
    catch (EValorNoValido e)
    {
      System.out.println(e.getMessage());
    }
    System.out.println("Contin�a la ejecuci�n");
  }
}
